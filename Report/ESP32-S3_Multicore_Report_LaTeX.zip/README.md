# Core Isolation on a Dual-Core Microcontroller — LaTeX source

IEEE conference-format report (IEEEtran) for CS363 Operating System Lab, IIIT Vadodara.

## Build

**Overleaf:** upload this zip as a new project. Set *Menu → Compiler* to **XeLaTeX**
(gives the same Times-compatible fonts as the reference PDF); **pdfLaTeX** also works.
Main document: `main.tex`.

**Locally (Tectonic):**

```bash
tectonic -X compile main.tex
```

**Locally (TeX Live / MacTeX):**

```bash
xelatex main && bibtex main && xelatex main && xelatex main
```

## Layout

| Path | Contents |
|---|---|
| `main.tex` | preamble, title, authors, section includes |
| `sections/00-abstract.tex` … `08-conclusion.tex` | report body |
| `sections/09-appendix.tex` | one-column appendix with the full source |
| `refs.bib` | references (IEEEtran style) |
| `figures/` | screenshots: `p*` = development phases (from the phase log), `e*` = experiments on the live board, `v30_*` = v3.0 |
| `data/` | measured data plotted with pgfplots (jitter histograms, hog and flash tick traces, command-latency CDF) |
| `code/Multicore_Web_Controller.ino` | firmware v3.1 exactly as measured (no credentials; those live in `secrets.h`, not included) |

All diagrams are TikZ and all charts are pgfplots, so they stay sharp and can be edited in the source.
